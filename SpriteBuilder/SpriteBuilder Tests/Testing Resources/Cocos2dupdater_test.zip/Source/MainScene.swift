import Foundation

class MainScene: CCNode {

}
