@interface MainScene : CCNode

@end
